-- --------------------------------------------------------
-- Host:                         htlvb-projekt
-- Server Version:               5.7.18-log - MySQL Community Server (GPL)
-- Server Betriebssystem:        Win64
-- HeidiSQL Version:             9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Exportiere Datenbank Struktur für 4ahwii_luger
CREATE DATABASE IF NOT EXISTS `4ahwii_luger` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `4ahwii_luger`;

-- Exportiere Struktur von Tabelle 4ahwii_luger.ranks
CREATE TABLE IF NOT EXISTS `ranks` (
  `RankID` int(11) NOT NULL AUTO_INCREMENT,
  `rank` varchar(255) NOT NULL,
  PRIMARY KEY (`RankID`),
  UNIQUE KEY `RankID` (`RankID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle 4ahwii_luger.ranks: ~0 rows (ungefähr)
/*!40000 ALTER TABLE `ranks` DISABLE KEYS */;
/*!40000 ALTER TABLE `ranks` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle 4ahwii_luger.reservations
CREATE TABLE IF NOT EXISTS `reservations` (
  `ReservationID` int(11) NOT NULL AUTO_INCREMENT,
  `TenniscourtID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `starttime` datetime NOT NULL,
  `duration` time NOT NULL,
  `RTypeID` int(11) NOT NULL,
  PRIMARY KEY (`ReservationID`),
  UNIQUE KEY `ReservationID` (`ReservationID`),
  KEY `TenniscourtID` (`TenniscourtID`),
  KEY `UserID` (`UserID`),
  KEY `RTypeID` (`RTypeID`),
  CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`TenniscourtID`) REFERENCES `tenniscourt` (`TenniscourtID`),
  CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`),
  CONSTRAINT `reservations_ibfk_3` FOREIGN KEY (`RTypeID`) REFERENCES `reservationtype` (`RTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle 4ahwii_luger.reservations: ~0 rows (ungefähr)
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle 4ahwii_luger.reservationtype
CREATE TABLE IF NOT EXISTS `reservationtype` (
  `RTypeID` int(11) NOT NULL AUTO_INCREMENT,
  `RType` varchar(255) NOT NULL,
  PRIMARY KEY (`RTypeID`),
  UNIQUE KEY `RTypeID` (`RTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle 4ahwii_luger.reservationtype: ~0 rows (ungefähr)
/*!40000 ALTER TABLE `reservationtype` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservationtype` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle 4ahwii_luger.tenniscourt
CREATE TABLE IF NOT EXISTS `tenniscourt` (
  `TenniscourtID` int(11) NOT NULL AUTO_INCREMENT,
  `Description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`TenniscourtID`),
  UNIQUE KEY `TenniscourtID` (`TenniscourtID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle 4ahwii_luger.tenniscourt: ~0 rows (ungefähr)
/*!40000 ALTER TABLE `tenniscourt` DISABLE KEYS */;
/*!40000 ALTER TABLE `tenniscourt` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle 4ahwii_luger.user
CREATE TABLE IF NOT EXISTS `user` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `Firstname` varchar(255) NOT NULL,
  `Lastname` varchar(255) NOT NULL,
  `EMail` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `RankID` int(11) NOT NULL,
  `Gender` varchar(255) DEFAULT NULL,
  `SkillLevel` varchar(255) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `UserID` (`UserID`),
  KEY `RankID` (`RankID`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`RankID`) REFERENCES `ranks` (`RankID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle 4ahwii_luger.user: ~0 rows (ungefähr)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
