﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Odbc;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tennisplatzreservierung
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btn_login_register_Click(object sender, EventArgs e)
        {
            Registration registration = new Registration();
            this.Hide();
            registration.ShowDialog();
        }
        public static byte[] GetHash(string inputString)
        {
            HashAlgorithm algorithm = MD5.Create();  //or use SHA256.Create();
            return algorithm.ComputeHash(Encoding.UTF8.GetBytes(inputString));
        }

        public static string GetHashString(string inputString)
        {
            StringBuilder sb = new StringBuilder();
            foreach (byte b in GetHash(inputString))
            {
                sb.Append(b.ToString("X2"));
            }

            return sb.ToString();
        }

        public static string GernerateSalt()
        {
            byte[] salt = new byte[32];
            RNGCryptoServiceProvider random = new RNGCryptoServiceProvider();
            random.GetNonZeroBytes(salt);
            return Convert.ToBase64String(salt);
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if (tbx_login_email.Text != string.Empty && mtbx_login_password.Text != string.Empty)
            {
                ConnectionClass connectionClass = new ConnectionClass();
                OdbcConnection Connection = connectionClass.GetConnection();

                string sql = string.Format("SELECT Password FROM tab_user WHERE EMail='{0}'", tbx_login_email.Text);
                OdbcCommand cmd = new OdbcCommand(sql, Connection);
                Connection.Open();
                string actualpassword = Convert.ToString(cmd.ExecuteScalar());
                Connection.Close();

                sql = string.Format("SELECT Salt FROM tab_user WHERE EMail='{0}'", tbx_login_email.Text);
                cmd = new OdbcCommand(sql, Connection);
                Connection.Open();
                string salt = Convert.ToString(cmd.ExecuteScalar());
                Connection.Close();

                string sourcepassword = GetHashString(mtbx_login_password.Text + salt);


                if (string.Compare(actualpassword, sourcepassword) == 0)
                {
                    sql = $"SELECT UserID, Firstname, Lastname, Birthdate, RollID, Gender, Skilllevel FROM tab_User where EMail='{tbx_login_email.Text}'";
                    OdbcDataAdapter da = new OdbcDataAdapter(sql, Connection);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgv_Login.DataSource = dt;

                    lbl_output.Text = ("Login erfolgreich!");
                    tenniscourtreservation form = new tenniscourtreservation();
                    string date = dgv_Login[3, 0].Value.ToString().Split(' ')[0];
                    string[] splitdate = date.Split('.');
                    date = $"{splitdate[2]}-{splitdate[1]}-{splitdate[0]}";

                    form.currentUser = new User(Convert.ToInt32(dgv_Login[0, 0].Value.ToString()), dgv_Login[1, 0].Value.ToString(), dgv_Login[2, 0].Value.ToString(), tbx_login_email.Text, date, Convert.ToInt32(dgv_Login[4, 0].Value.ToString()), dgv_Login[5, 0].Value.ToString(), dgv_Login[6, 0].Value.ToString());
                    this.Hide();
                    form.ShowDialog();

                }
                else
                {
                    lbl_output.Text = ("Falsche E-Mail oder Passwort!");
                }
            }
            else
            {
                lbl_output.Text = "Bitte geben sie EMail und Passwort ein";
            }

        }
    }
}
