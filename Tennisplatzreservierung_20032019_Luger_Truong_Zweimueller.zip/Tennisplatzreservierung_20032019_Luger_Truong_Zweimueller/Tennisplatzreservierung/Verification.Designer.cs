﻿namespace Tennisplatzreservierung
{
    partial class Verification
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_verification_users = new System.Windows.Forms.DataGridView();
            this.VerificationColumn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.RollColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_verification_users)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_verification_users
            // 
            this.dgv_verification_users.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_verification_users.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_verification_users.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.VerificationColumn,
            this.RollColumn});
            this.dgv_verification_users.Location = new System.Drawing.Point(12, 12);
            this.dgv_verification_users.Name = "dgv_verification_users";
            this.dgv_verification_users.Size = new System.Drawing.Size(983, 550);
            this.dgv_verification_users.TabIndex = 0;
            this.dgv_verification_users.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_verification_users_CellContentClick);
            // 
            // VerificationColumn
            // 
            this.VerificationColumn.DataPropertyName = "Text";
            this.VerificationColumn.Frozen = true;
            this.VerificationColumn.HeaderText = "Verifizierung";
            this.VerificationColumn.Name = "VerificationColumn";
            this.VerificationColumn.Text = "Bestätigen";
            this.VerificationColumn.ToolTipText = "test";
            this.VerificationColumn.UseColumnTextForButtonValue = true;
            // 
            // RollColumn
            // 
            this.RollColumn.HeaderText = "Rolle";
            this.RollColumn.Items.AddRange(new object[] {
            "Admin",
            "User"});
            this.RollColumn.Name = "RollColumn";
            // 
            // Verification
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1007, 574);
            this.Controls.Add(this.dgv_verification_users);
            this.Name = "Verification";
            this.Text = "Verification";
            this.Load += new System.EventHandler(this.Verification_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_verification_users)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_verification_users;
        private System.Windows.Forms.DataGridViewButtonColumn VerificationColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn RollColumn;
    }
}