﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Odbc;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tennisplatzreservierung
{
    public partial class Registration : Form
    {

        private OdbcConnection connection = null;
        private OdbcConnection Connection
        {
            get
            {
                if (connection == null)
                {
                    ConnectionClass connectionClass = new ConnectionClass();
                    connection = connectionClass.GetConnection();
                }
                return connection;
            }
        }

        public Registration()
        {
            InitializeComponent();
        }

        private void Registration_Load(object sender, EventArgs e)
        {
            
        }

        private void btn_registration_register_Click(object sender, EventArgs e)
        {
            //ConncetionToMySQLDatabase
            User userToRegister = ReadRegistrationDataAndCreateUser();
            string sqlQuery = $"INSERT INTO tab_user (Firstname, Lastname, EMail, Password, RollID, Gender, SkillLevel, Birthdate, Salt, Verified) VALUES ({userToRegister.ToString()})";
            OdbcCommand command = new OdbcCommand(sqlQuery, Connection);
            try
            {
                Connection.Open();
                command.ExecuteNonQuery();
                Connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                Environment.Exit(1);
            }

            sqlQuery = $"SELECT UserID FROM tab_user WHERE EMail = '{tbx_registration_email.Text}'";
            command = new OdbcCommand(sqlQuery, Connection);
            int userID=0;
            try
            {
                Connection.Open();
                userID = Convert.ToInt32(command.ExecuteScalar().ToString());
                Connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                Environment.Exit(1);
            }

            string gender = "male";
            if (rbn_registration_female.Checked)
            {
                gender = "female";
            }

            tenniscourtreservation form = new tenniscourtreservation();
            form.currentUser = new User(userID,tbx_registration_firstname.Text,tbx_registration_lastname.Text,tbx_registration_email.Text,tbx_registration_age.Text,3,gender,cbx_registration_skill_level.Text);
            form.ShowDialog();
            this.Hide();
        }



        private void mtbx_registration_password2_Leave(object sender, EventArgs e)
        {
            lbl_password_correct.Text = "";
            string ppwCorrect = "Passwort simmt überein!";
            if (mtbx_registration_password1.Text == mtbx_registration_password2.Text)
            {

                lbl_password_correct.Text = ppwCorrect;
            }                    
        }

        private User ReadRegistrationDataAndCreateUser()
        {
            string firstname, lastname, email, password, gender, skillLevel;
            int rollid, verified;
            string birthdate;
            User userToRegister = null;

            firstname = tbx_registration_firstname.Text;
            lastname = tbx_registration_lastname.Text;
            email = tbx_registration_email.Text;
            password = mtbx_registration_password1.Text;
            rollid = 3;
            verified = 0;

            skillLevel = cbx_registration_skill_level.Text;



            if (rbn_registration_male.Checked)
            {
                gender = "male";
            }
            else
            {
                gender = "female";
            }

            birthdate = tbx_registration_age.Text;
            try
            {
                userToRegister = new User(firstname,lastname,email,password,birthdate,rollid,gender,skillLevel,verified);
            }
            catch(ApplicationException ex)
            {
                MessageBox.Show(ex.ToString());
                tbx_registration_age.BackColor = Color.Red;
            }
            return userToRegister;
            
        }
    }
}
