﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Odbc;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tennisplatzreservierung
{
    public partial class Verification : Form
    {
        public Verification()
        {
            InitializeComponent();
            dgv_verification_Update();
        }

        private OdbcConnection connection=null;
        private OdbcConnection Connection
        {
            get
            {
                if (connection == null)
                {
                    ConnectionClass connectionClass = new ConnectionClass();
                    connection = connectionClass.GetConnection();
                }
                return connection;            
            }
         
        }

        private void dgv_verification_Update()
        {
            try
            {
                string sql = string.Format("SELECT UserID, Firstname as Vorname, Lastname as Nachname, Email, Gender as Geschlecht, SkillLevel, Birthdate as Geburtsdatum FROM tab_user WHERE Verified = 0 OR rollID = 3");
                OdbcDataAdapter da = new OdbcDataAdapter(sql, Connection);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgv_verification_users.DataSource = dt;

                //for(int i = 0; i < dgv_verification_users.Rows.Count; i++)
                //{
                //    dgv_verification_users.Rows[i].Cells[1].Value = dgv_verification_users.Rows[i].Cells["RollID"].Value;
                //}

            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler: " + ex.ToString());
                Environment.Exit(1);
            }
            
        }

        private void dgv_verification_users_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                try
                {
                    int rollID;
                    if (dgv_verification_users[1, e.RowIndex].Value == null) dgv_verification_users[1, e.RowIndex].Value = "User";
                    if (dgv_verification_users[1, e.RowIndex].Value.ToString() == "Admin") rollID = 1;
                    else
                    {
                        if (dgv_verification_users[1, e.RowIndex].Value.ToString() == "User") rollID = 2;
                        else rollID = 3;
                    }

                    
                    string sql = $"UPDATE tab_user SET Verified = 1, RollID = {rollID} WHERE UserID = {dgv_verification_users[2, e.RowIndex].Value.ToString()}";
                    OdbcCommand cmd = new OdbcCommand(sql, Connection);
                    Connection.Open();
                    cmd.ExecuteNonQuery();
                    Connection.Close();

                    MessageBox.Show("Benutzer verifiziert!");
                    dgv_verification_Update();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }

        private void Verification_Load(object sender, EventArgs e)
        {

        }
    }
}
