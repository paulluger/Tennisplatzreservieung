﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Tennisplatzreservierung
{
    public class User
    {
        private string firstName;
        private string lastName;
        private string email;
        private string password;
        private string salt;
        private int rollID;
        private string gender;
        private string skillLevel;
        private int userID;
        private string birthdate;
        
        public string FirstName
        {
            get { return firstName; }
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new ApplicationException("Vorname ist leer!");
                else
                    firstName = value;
            }
        }
        public string LastName
        {
            get { return lastName; }
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new ApplicationException("Nachname ist leer!");
                else
                    lastName = value;
            }
        }
        public string Email
        {
            get { return email; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ApplicationException("E-Mail ist leer!");
                }

                if (value.Contains("@"))
                {
                    string[] splitEmail = value.Split('@');
                    if (splitEmail[1].Contains("."))
                        email = value;
                }
                else
                {
                    throw new ApplicationException("E-Mail ist nicht gültig!");
                }
            }
        }
        public string Password
        {
            get { return password; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ApplicationException("Passwort ist leer!");
                }
                else
                {
                    password = GetHashString(value+Salt);
                }

            }
        }

        public string Salt
        {
            get { return salt; }
            set { salt = value; }
        }

        public int Verified { get; set; }

        public int RollID
        {
            get { return rollID; }
            set
            {
                if (value < 0 || value > 3)
                    throw new ApplicationException("Mögliche Ränge sind 3...nicht verifiziert 2...Mitglied 1...Admin!");
                else
                    rollID = value;
            }
        }

        public string Gender
        {
            get
            {
                return gender;
            }
            set
            {
                if(value!="male" && value != "female")
                {
                    throw new ApplicationException("Gender nicht gültig!");
                }
                else
                {
                    gender = value;
                }
            }
        }

        //public string Gender { get { return gender; } set { } }
        public string SkillLevel { get { return skillLevel; } set { skillLevel = value; } }
        public string BirthDate
        {
            get
            {
                return birthdate;
            }
            set
            {
                if (value.Contains('.'))
                {
                    value=value.Replace('.', '-');
                }
                if (value.Contains('-'))
                {
                    string[] parts = value.Split('-');
                    if (parts.Count() == 3)
                    {
                        if (parts[0].Length == 4 && Convert.ToInt32(parts[1]) <= 12 && Convert.ToInt32(parts[1]) >= 1 && Convert.ToInt32(parts[2]) <= 31 && Convert.ToInt32(parts[2]) >= 1)
                        {
                            birthdate = value;
                        }
                        else
                        {
                            throw new ApplicationException("Das Eingabeformat entspricht nicht den Anforderungen!");
                        }
                    }
                    else
                    {
                        throw new ApplicationException("Das Eingabeformat entspricht nicht den Anforderungen!");
                    }
                }
                else
                {
                    throw new ApplicationException("Das Eingabeformat entspricht nicht den Anforderungen!");
                }

            }
        }
        public int UserID { get { return userID; } set { userID = value; } }

      

        public User() { }
        public User(int _userID,string _firstname, string _lastname, string _email, string _birthDate, int _rollID, string _gender, string _skillevel)
        {
            UserID = _userID;
            FirstName = _firstname;
            LastName = _lastname;
            Email = _email;
            BirthDate = _birthDate;
            RollID = _rollID;
            Gender = _gender;
            SkillLevel = _skillevel;
        }
        public User(string _firstname, string _lastname, string _email, string _password, string _birthDate, int _rollID, string _gender, string _skillevel, int _verified)
        {
            FirstName = _firstname;
            LastName = _lastname;
            Email = _email;
            Salt = GenerateSalt();
            Password = _password;
            BirthDate = _birthDate;
            RollID = _rollID;
            Gender = _gender;
            SkillLevel = _skillevel;
            Verified = _verified;
        }

        public override string ToString()
        {
            return "'" + FirstName + "','" + LastName + "','" + Email + "','" + Password + "','" + RollID + "','" + Gender + "','" + SkillLevel + "','" + BirthDate + "','" + Salt + "','" + Verified + "'";
        }
        public static byte[] GetHash(string inputString)
        {
            HashAlgorithm algorithm = MD5.Create();
            return algorithm.ComputeHash(Encoding.UTF8.GetBytes(inputString));
        }

        public static string GetHashString(string inputString)
        {
            StringBuilder sb = new StringBuilder();
            foreach (byte b in GetHash(inputString))
            {
                sb.Append(b.ToString("X2"));
            }

            return sb.ToString();
        }

        public static string GenerateSalt()
        {
            byte[] salt = new byte[32];
            RNGCryptoServiceProvider random = new RNGCryptoServiceProvider();
            random.GetNonZeroBytes(salt);
            return Convert.ToBase64String(salt);
        }
    }
}

