﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tennisplatzreservierung
{
    public partial class tenniscourtreservation : Form
    {
        public User currentUser;
        public tenniscourtreservation()
        {
            InitializeComponent();
            
        }

        private void lbl_Login_Click(object sender, EventArgs e)
        {

        }

        private void tenniscourtreservation_Load(object sender, EventArgs e)
        {
            //lbl_Login.Text = currentUser.ToString();
            if (currentUser.RollID != 1)
            {
                btn_admin.Visible = false;
            }
        }

        private void btn_admin_Click(object sender, EventArgs e)
        {
            Admin adminForm = new Admin();
            adminForm.ShowDialog();
        }
    }
}
